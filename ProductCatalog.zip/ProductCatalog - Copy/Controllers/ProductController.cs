﻿using System.Collections.Generic;
using System.Web.Mvc;
using ProductCatalog.Models;

namespace ProductCatalog.Controllers
{
    public class ProductController : Controller
    {
        // Product List Page
        public ActionResult Index()
        {
            List<Product> products = GetProducts();

            return View(products);
        }

        // Product Details Page
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Index");
            }

            List<Product> products = GetProducts();

            Product product = products.Find(
                p => p.ProductId == id.Value
            );

            if (product == null)
            {
                return HttpNotFound();
            }

            return View(product);
        }

        // Product Data
        private List<Product> GetProducts()
        {
            return new List<Product>()
            {
                new Product
                {
                    ProductId = 1,
                    ProductName = "Laptop",
                    Category = "Electronics",
                    Price = 55000,
                    Description = "High performance laptop"
                },

                new Product
                {
                    ProductId = 2,
                    ProductName = "Mobile Phone",
                    Category = "Electronics",
                    Price = 25000,
                    Description = "5G smartphone"
                },

                new Product
                {
                    ProductId = 3,
                    ProductName = "Headphones",
                    Category = "Accessories",
                    Price = 2000,
                    Description = "Wireless headphones"
                }
            };
        }
    }
}